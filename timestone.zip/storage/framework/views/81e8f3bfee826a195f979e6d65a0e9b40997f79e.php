<?php $__env->startSection('projects'); ?>
<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projects): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!--- Activity Group menu -->
<div class="row">
    <div class="col-sm-3 pt-3">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title text-center text-uppercase"><?php echo e($projects -> id); ?> - <?php echo e($projects -> title); ?></h5>
                <p class="card-text text-center"><?php echo e($projects -> description); ?></p>
                <h4 class="text-center">00:00</h4>
            </div>
        </div>
    </div>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?><?php /**PATH C:\wamp64\www\projetos\Laravel\timestone\resources\views/_partials/Projects.blade.php ENDPATH**/ ?>