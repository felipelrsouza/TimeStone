<?php $__env->startSection('title', 'Projects'); ?>
<?php $__env->startSection('content'); ?>




<div id="project-create-container" class="col-md-6 offset-md-3">
    <br>
<h2 class="text-center">Projects</h2>
<br>
<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h6><?php echo e($project -> id); ?> - <?php echo e($project -> title); ?> - <span style="cursor: pointer" data-id='<?php echo e($project -> id); ?>' onClick='deleteProject(this)' ><i class="fa-solid fa-trash"></i> Delete<br><br></span></h6>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<h4>Create a new project</h4>
<form action="/projects" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="title">Title:</label>
        <input type="text" class="form-control" id="title" name="title" placeholder="Project title.">
    </div>
    <div class="form-group">
        <label for="title">Description:</label>
        <textarea name="description" id="description" class="form-control" placeholder="Short project description."></textarea>
    </div>
    <br>
    <div class="text-center">
<input type="submit" class="btn btn-primary " value="Create">
</div>
</form>


</div>

</div>

<!-- Axios JS -->
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>

<!-- General Page JS -->
<script src="/js/general_script.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\projetos\Laravel\timestone\resources\views//projects.blade.php ENDPATH**/ ?>