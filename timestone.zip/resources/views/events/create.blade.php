@extends('layout.main')
@section('title', 'Criar Evento')
@section ('content')

<h1>Crie um evento</h1>

@endsection